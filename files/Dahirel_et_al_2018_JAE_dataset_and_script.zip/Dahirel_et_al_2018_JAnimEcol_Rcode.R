####################
## R code for analyses presented in:
## Urbanization-driven changes in web-building and body size in an orb-web spider
## Maxime Dahirel, Maarten De Cock, Pieter Vantieghem and Dries Bonte
## Journal of Animal Ecology
## last checked: August 23, 2018
## corresponding author: MD: maxime.dahirel [at] yahoo.fr ; https://mdahirel.github.io/ ; Twitter: @mdahirel
####################

### the script assumes the three associated datasets are loaded in R under the following names:
## data: the main dataset with individual trait values  ("individual_spider_info.txt" ; 621 rows)
## popsize: the secondary dataset with population densities ("population_densities_info.txt" ; 62 rows)
## landscape_info: the dataset used to compare landscape-level metrics ("landscape_urbanization_info.txt" ; 21 rows)

## NOTE: given the analysis involves numerous repetitive tasks
## and the copy-pasting would rapidly make the code tedious and difficult to read for an external reader,
## we made the choice to present some diagnostics and checks for only one of the models presented
## sacrificing completeness in order to maximize readability.
## We consider that any reader able to successfully fit the detailed model based on instructions is likely able to adapt the code chunks to fit the others
## if that is not the case, the corresponding author will be more than happy to help you navigate the code

## MCMC models are memory-consuming; always run test versions with smaller numbers of iterations first
## to gauge your computer and how much time it may take


#################################
#### STEP -1: load needed packages
#################################


## install them first if not already installed
# if (!require("coda")) install.packages("coda")
# if (!require("MCMCglmm")) install.packages("MCMCglmm")
# if (!require("chron")) install.packages("chron")
# if (!require("ncf")) install.packages("ncf")
# if (!require("bayesplot")) install.packages("bayesplot")

library(MCMCglmm)
library(coda)
library(chron)
library(ncf)
library(bayesplot)


##################################
#### STEP 0: some data reformatting
##################################


# convert dates into numerical values
data$day <- as.numeric(chron(dates. = as.character(data$Date), format = c(dates = "d/m/y"), origin. = c(1, 1, 2014)))
popsize$day <- as.numeric(chron(dates. = as.character(popsize$Date), format = c(dates = "d/m/y"), origin. = c(1, 1, 2014)))

# standardize all continuous variables involved in mixed models except counts
popsize$sday <- scale(popsize$day)
data$sday <- scale(data$day)
data$sCTsize <- scale(data$CTsize)
data$sMesh <- scale(data$Mesh)
data$sSurface <- scale(data$EfSurface)


######################################################################
#### STEP 1: check landscape-level metrics (cf Supplementary Figure S1)
######################################################################


landscape_info$colour <- landscape_info$landscape_urba
levels(landscape_info$colour) <- c("black", "#00f5e5", "#c35800")
landscape_info$colour <- as.character(landscape_info$colour)
plot(CORINE_percent_artificial ~ percent_buildings_landscape, data = landscape_info, ylab = "CORINE-base % of artificial surfaces", xlab = "% of surfaces occupied by buildings", xlim = c(0, 40), ylim = c(0, 100), las = 1, bg = landscape_info$colour, pch = 21, bty = "l")
abline(v = c(3, 10), lty = 2)
abline(h = c(20, 70), lty = 2)
cor.test(landscape_info$CORINE_percent_artificial, landscape_info$percent_buildings_landscape, method = "spearman")


##############################
### STEP 2: UNIVARIATE MODELS
##############################


niterations <- 13000 #
nburnin <- 3000 #
nthin <- 10 # default numbers set to low values for debugging/code exploration; values used in article 1000000, 250000, 750 respectively


### model for population density

# set the prior
prior_1 <- list(R = list(R1 = list(V = diag(1), n = 1)), G = list(G1 = list(V = diag(1), n = 1, alpha.mu = rep(0, 1), alpha.V = diag(1) * 25^4)))

## fit three times the model, one per chain, with startpoints changed by changing the random seed
## the argument verbose is set to TRUE here; set it to FALSE if you have many iterations and don't want to have iteration numbers scroll on your screen for hours
set.seed(1)
modPOP <- MCMCglmm(Naraneus ~ landscape_urba + local_urba + sday, random = ~PLOT, family = "poisson", data = popsize, verbose = T, prior = prior_1, pr = TRUE, nitt = niterations, burnin = nburnin, thin = nthin)
set.seed(2)
modPOPa <- MCMCglmm(Naraneus ~ landscape_urba + local_urba + sday, random = ~PLOT, family = "poisson", data = popsize, verbose = T, prior = prior_1, pr = TRUE, nitt = niterations, burnin = nburnin, thin = nthin)
set.seed(3)
modPOPb <- MCMCglmm(Naraneus ~ landscape_urba + local_urba + sday, random = ~PLOT, family = "poisson", data = popsize, verbose = T, prior = prior_1, pr = TRUE, nitt = niterations, burnin = nburnin, thin = nthin)


#### MODEL DIAGNOSTICS
#### For simplicity, only presented for this model; please modify and adapt for the other models

summary(modPOP) ## model summaries for each individual chain; MCMCglmm does not allow chain merging within MCMCglmm objects
summary(modPOPa)
summary(modPOPb)

mpopFIX <- mcmc.list(modPOP$Sol, modPOPa$Sol, modPOPb$Sol) ### extract fixed effects and combine them for all three chains
mpopVCV <- mcmc.list(modPOP$VCV, modPOPa$VCV, modPOPb$VCV) ### extract random effects(variance_covariance matrix) and combine them for all three chains

### convergence of the three fitted chains
mcmc_trace(mpopFIX[, 1:6])
mcmc_trace(mpopVCV) ## chains should be stationary (flat with only random noise) and overlap each other
### the [,1:6] is here to only plot the actual fixed effects;
### there are other parameters in this object, but they are the group level estimates (the equivalent of BLUPs)
### a version of this [,1:6] will be needed for each model, normally the first 6 parameters every time
### but check the summaries above to determine if you want to be sure about which parameters you want to display

max(gelman.diag(mpopFIX[, 1:6])$psrf) # should be <1.1; if not, check parameter per parameter instead of just the maximum
max(gelman.diag(mpopVCV)$psrf) # and refit model with more iterations and/or a stronger prior; it has not converged


### within-chain serial autocorrelation; absolute value should be <0.1 at all lags
mcmc_acf_bar(mpopFIX[, 1:6]) + hline_at(c(-0.1, 0.1))
mcmc_acf_bar(mpopVCV) + hline_at(c(-0.1, 0.1))
###

### check for residual spatial autocorrelation
residPOP <- (popsize$Naraneus - predict(modPOP, marginal = NULL)[, 1]) / sqrt(predict(modPOP, marginal = NULL)[, 1]) # Pearson residuals
residPOPa <- (popsize$Naraneus - predict(modPOPa, marginal = NULL)[, 1]) / sqrt(predict(modPOPa, marginal = NULL)[, 1]) # Pearson residuals
residPOPb <- (popsize$Naraneus - predict(modPOPb, marginal = NULL)[, 1]) / sqrt(predict(modPOPb, marginal = NULL)[, 1]) # Pearson residuals
### we use Pearson residuals for Poisson models (density and egg numbers)
### remove the /sqrt(...) for Gaussian models (see below for an example)
residPOPmean <- rowMeans(data.frame(residPOP, residPOPa, residPOPb)) ### we average residuals calculated on the three chains
splicor <- spline.correlog(x = popsize$LON, y = popsize$LAT, z = residPOPmean, latlon = TRUE, quiet = TRUE)
plot(splicor) # no evidence of residual spatial autocorrelation


#### MODEL ANALYSIS AND INFERENCE
#### if all parameters and chains are clear, one can now do inferences based on parameter summaries
summary(mpopFIX[, 1:6]) ## summary of fixed effects for all three chains
summary(mpopVCV) ## summary of random effects for all three chains

##### R2c and R2m
### we present here the calculation for one chain, MCMC outputs from several chains can be combined as needed using mcmc.list (see above)

### for Poisson model, one needs to also fit a "null" model to estimate R2C and R2m (see Supplementary Material of Nakagawa and Schielzeth 2013 R� paper)
set.seed(1)
modPOP0 <- MCMCglmm(Naraneus ~ 1, random = ~PLOT, family = "poisson", data = popsize, verbose = T, prior = prior_1, pr = TRUE, nitt = niterations, burnin = nburnin, thin = nthin)

mmF <- modPOP
mmF0 <- modPOP0
N <- 6 # number of fixed effects coef in model
vmVarF <- numeric(1000)
for (i in 1:1000) {
  Var <- var(as.vector(as.vector(mmF$Sol[i, ])[1:N] %*% t(mmF$X)))
  vmVarF[i] <- Var
}
R2m <- vmVarF / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2] + log(1 + 1 / exp(mmF0$Sol[, 1])))
R2c <- (vmVarF + mmF$VCV[, 1]) / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2] + log(1 + 1 / exp(mmF0$Sol[, 1])))
### IMPORTANT! there are two levels in the covariance matrix
## [,1]: landscape-level (co)variance
## [,2]: residual (co)variance

### for ALL other models in the analysis there will be 3 levels:
## [,1]: landscape-level (co)variance
## [,2]: population-level (co)variance
## [,3]: residual (co)variance



### spider traits

prior_1b <- list(R = list(R1 = list(V = diag(1), n = 1)), G = list(G1 = list(V = diag(1), n = 1, alpha.mu = rep(0, 1), alpha.V = diag(1) * 25^4), G2 = list(V = diag(1), n = 1, alpha.mu = rep(0, 1), alpha.V = diag(1) * 25^4)))

set.seed(1)
modA <- MCMCglmm(sSurface ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modS <- MCMCglmm(sCTsize ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modM <- MCMCglmm(sMesh ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modE <- MCMCglmm(Eggs ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "poisson", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)

set.seed(2)
modAa <- MCMCglmm(sSurface ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modSa <- MCMCglmm(sCTsize ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modMa <- MCMCglmm(sMesh ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modEa <- MCMCglmm(Eggs ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "poisson", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)

set.seed(3)
modAb <- MCMCglmm(sSurface ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modSb <- MCMCglmm(sCTsize ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modMb <- MCMCglmm(sMesh ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "gaussian", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)
modEb <- MCMCglmm(Eggs ~ landscape_urba + local_urba + sday, random = ~PLOT + PLOT:Site, data = data, family = "poisson", verbose = F, pr = TRUE, prior = prior_1b, nitt = niterations, burnin = nburnin, thin = nthin)




#### MODEL DIAGNOSTICS
### see examples given above for the population density model

### for gaussian variables, the code for R2 and for spatial autocorrelation checks changes slightly
### an example using body size is presented below

# R�

### script for r2m and r2c for mcmcglmm linear models
mmF <- modS
N <- 6 # number of fixed effects coef in model

vmVarF <- numeric(1000)
for (i in 1:1000) {
  Var <- var(as.vector(as.vector(mmF$Sol[i, ])[1:N] %*% t(mmF$X)))
  vmVarF[i] <- Var
}

R2m <- vmVarF / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2] + mmF$VCV[, 3])
R2c <- (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2]) / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2] + mmF$VCV[, 3])

### for spider traits (including eggs), we can remove the residual variance from the equation so we estimate the R2 at the population level
### which correspond roughly, as far as I can tell, to the proportion of population-level variance explained by fixed-effects and higher-level random effects
R2m_pop <- vmVarF / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2])
R2c_pop <- (vmVarF + mmF$VCV[, 1]) / (vmVarF + mmF$VCV[, 1] + mmF$VCV[, 2])

# autocorrelation

residS <- (data$sCTsize - predict(modS, marginal = NULL)[, 1])
residSa <- (data$sCTsize - predict(modSa, marginal = NULL)[, 1])
residSb <- (data$sCTsize - predict(modSb, marginal = NULL)[, 1])
residSmean <- rowMeans(data.frame(residS, residSa, residSb))
splicor <- spline.correlog(x = data$LON, y = data$LAT, z = residSmean, latlon = TRUE, quiet = TRUE)
plot(splicor) # no evidence of residual spatial autocorrelation




###############################################
### STEP 3: MULTIVARIATE MODELING: spider traits
###############################################

niterations <- 13000 #
nburnin <- 3000 #
nthin <- 10 # default numbers set to low values for debugging/code exploration; values used in article 3300000, 300000, 1000 respectively



### setting priors
prior_4 <- list(R = list(R1 = list(V = diag(4), n = 4)), G = list(G1 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 1000), G2 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 1000)))


set.seed(1)
modMULTI <- MCMCglmm(cbind(sCTsize, sMesh, sSurface, Eggs) ~ 0 + trait + trait:(landscape_urba + local_urba + sday),
  random = ~us(trait):PLOT + us(trait):PLOT:Site, rcov = ~us(trait):units,
  data = data, family = c("gaussian", "gaussian", "gaussian", "poisson"), prior = prior_4, nitt = niterations, burnin = nburnin, thin = nthin, verbose = T, pr = TRUE
) ## about 3 hours per chain
set.seed(2)
modMULTIa <- MCMCglmm(cbind(sCTsize, sMesh, sSurface, Eggs) ~ 0 + trait + trait:(landscape_urba + local_urba + sday),
  random = ~us(trait):PLOT + us(trait):PLOT:Site, rcov = ~us(trait):units,
  data = data, family = c("gaussian", "gaussian", "gaussian", "poisson"), prior = prior_4, nitt = niterations, burnin = nburnin, thin = nthin, verbose = T, pr = TRUE
)
set.seed(3)
modMULTIb <- MCMCglmm(cbind(sCTsize, sMesh, sSurface, Eggs) ~ 0 + trait + trait:(landscape_urba + local_urba + sday),
  random = ~us(trait):PLOT + us(trait):PLOT:Site, rcov = ~us(trait):units,
  data = data, family = c("gaussian", "gaussian", "gaussian", "poisson"), prior = prior_4, nitt = niterations, burnin = nburnin, thin = nthin, verbose = T, pr = TRUE
)

mMULTIFIX <- mcmc.list(modMULTI$Sol, modMULTIa$Sol, modMULTIb$Sol) ### extract fixed effects and combine them for all three chains
mMULTIVCV <- mcmc.list(modMULTI$VCV, modMULTIa$VCV, modMULTIb$VCV) ### extract random effects(variance_covariance matrix) and combine them for all three chains


### NOTE on peeking inside a *multivariate* MCMCglmm object
### fixed effects for all responses are included in the mod$Sol output
### 6 parameters*4traits, so...
summary(mMULTIFIX[, 1:24])
### will give you the info you need without having to see all the BLUPs

### for the random effects, we have now three covariance matrices; landscape-level, population-level, residual
### see e.g.
summary(modMULTI)
### each made of 4 traits * 4traits = 16 values
### so if we want to have them separately, we can do

mMULTIVCV_landscape <- mMULTIVCV[, 1:16]
mMULTIVCV_population <- mMULTIVCV[, 17:32]
mMULTIVCV_residual <- mMULTIVCV[, 33:48]

# once the covariance matrices are separated, we can use posterior.cor to convert covariances to correlations !

## compare
summary(mMULTIVCV_landscape)
## with
summary(mcmc.list(posterior.cor(modMULTI$VCV[, 1:16]), posterior.cor(modMULTIa$VCV[, 1:16]), posterior.cor(modMULTIb$VCV[, 1:16])))
### posterior.cor is a MCMCglmm function, so does not play well with multiple MCMC chains combined in lists
### so needs to apply it to each chain, and then combine the correlation matrices in a new MCMClist

### PLEASE see tools described before to diagnose your model; they apply here
### NOTE that the predict() output of a multivariate MCMCglmm will give you all your traits, in order, in one object
### so here, if you want predictions only for body size, the first trait, you will have to specify
### predict(modMULTI)[,1:621]





###############
### NOT USED IN PAPER: MULTIVARIATE MODELING: spider traits  with variable covariance matrix
###############

###### we show here for information how to modify the multivariate model
###### in case we want the (co)variance not only to vary depending on the hierarchical level, as in the publication,
###### but also depending on urbanisation level (for instance, less trait variance in urban landscapes because of selection)

### We were unable to obtain models with satisfactory diagnostics here, even after over 20 million iterations
### exploration of model shows that (assuming posterior is correctly sampled, which it may not be, see line above)
### there is no evidence this model is actually any different from the multivariate one in the article, which has more constrained covariances
### (i.e. covariances at low and high urbanisation levels are not different from each other)
### but it may be that we don't have enough data, or not informative enough priors

### more covariance matrices, more parameters, so the prior is more complex
prior_4bis <- list(R = list(R1 = list(V = diag(4), n = 4)), G = list(G1 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4), G2 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4), G3 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4), G4 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4), G5 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4), G6 = list(V = diag(4), n = 4, alpha.mu = rep(0, 4), alpha.V = diag(4) * 25^4)))


### on chain of the model: note how the rendom formula changes
set.seed(1)
modMULTI_bis <- MCMCglmm(cbind(sCTsize, sMesh, sSurface, Eggs) ~ 0 + trait + trait:(landscape_urba + local_urba + sday),
  random = ~us(trait:at.level(landscape_urba, "low_urban")):PLOT +
    us(trait:at.level(landscape_urba, "medium_urban")):PLOT +
    us(trait:at.level(landscape_urba, "high_urban")):PLOT +
    us(trait:at.level(local_urba, "low_urban")):PLOT:Site +
    us(trait:at.level(local_urba, "medium_urban")):PLOT:Site +
    us(trait:at.level(local_urba, "high_urban")):PLOT:Site,
  rcov = ~us(trait):units,
  data = data, family = c("gaussian", "gaussian", "gaussian", "poisson"), prior = prior_4bis, nitt = niterations, burnin = nburnin, thin = nthin, verbose = T, pr = TRUE
)
